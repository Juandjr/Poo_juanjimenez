-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:8111
-- Tiempo de generación: 23-08-2023 a las 19:50:53
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `prueba2_u3`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiantes`
--

CREATE TABLE `estudiantes` (
  `estu_codigo` int(11) NOT NULL,
  `estu_cedula` int(11) NOT NULL,
  `estu_apellido` varchar(40) NOT NULL,
  `estu_nombre` varchar(40) NOT NULL,
  `estu_mail` varchar(40) NOT NULL,
  `estu_telefono` int(11) NOT NULL,
  `estu_direccion` varchar(40) NOT NULL,
  `estu_materia` varchar(40) NOT NULL,
  `estu_estado` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `estudiantes`
--

INSERT INTO `estudiantes` (`estu_codigo`, `estu_cedula`, `estu_apellido`, `estu_nombre`, `estu_mail`, `estu_telefono`, `estu_direccion`, `estu_materia`, `estu_estado`) VALUES
(1, 123, 'das', 'asd', 'asd', 123, 'asd', 'INGLES', 'Activo'),
(3, 159, 'nvb', 'nbv', 'nbv', 159, 'nvb', 'INGLES', 'Activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `horario`
--

CREATE TABLE `horario` (
  `horario_codigo` int(11) NOT NULL,
  `horario_hora` varchar(40) NOT NULL,
  `horario_profe` varchar(40) NOT NULL,
  `horario_disponibilidad` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `horario`
--

INSERT INTO `horario` (`horario_codigo`, `horario_hora`, `horario_profe`, `horario_disponibilidad`) VALUES
(1, '7 am', 'Javier Cevallos', 'DISPONIBLE');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `laboratorio`
--

CREATE TABLE `laboratorio` (
  `lab_codigo` int(11) NOT NULL,
  `lab_equipos` varchar(40) NOT NULL,
  `lab_tamaño` int(40) NOT NULL,
  `lab_ubicacion` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `laboratorio`
--

INSERT INTO `laboratorio` (`lab_codigo`, `lab_equipos`, `lab_tamaño`, `lab_ubicacion`) VALUES
(1, 'Computadores,Ventiladores,proyector', 45, '1er Piso');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesor`
--

CREATE TABLE `profesor` (
  `profe_codigo` int(11) NOT NULL,
  `profe_cedula` int(11) NOT NULL,
  `profe_apellido` varchar(40) NOT NULL,
  `profe_nombre` varchar(40) NOT NULL,
  `profe_mail` varchar(40) NOT NULL,
  `profe_telefono` int(11) NOT NULL,
  `profe_direccion` varchar(40) NOT NULL,
  `profe_materia` varchar(40) NOT NULL,
  `profe_estado` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `profesor`
--

INSERT INTO `profesor` (`profe_codigo`, `profe_cedula`, `profe_apellido`, `profe_nombre`, `profe_mail`, `profe_telefono`, `profe_direccion`, `profe_materia`, `profe_estado`) VALUES
(1, 6969, 'coito', 'jorge', 'asdasd', 9669, 'tucasa', 'riko', 'Activo');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `estudiantes`
--
ALTER TABLE `estudiantes`
  ADD PRIMARY KEY (`estu_codigo`);

--
-- Indices de la tabla `horario`
--
ALTER TABLE `horario`
  ADD PRIMARY KEY (`horario_codigo`);

--
-- Indices de la tabla `laboratorio`
--
ALTER TABLE `laboratorio`
  ADD PRIMARY KEY (`lab_codigo`);

--
-- Indices de la tabla `profesor`
--
ALTER TABLE `profesor`
  ADD PRIMARY KEY (`profe_codigo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `estudiantes`
--
ALTER TABLE `estudiantes`
  MODIFY `estu_codigo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `horario`
--
ALTER TABLE `horario`
  MODIFY `horario_codigo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `laboratorio`
--
ALTER TABLE `laboratorio`
  MODIFY `lab_codigo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `profesor`
--
ALTER TABLE `profesor`
  MODIFY `profe_codigo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
